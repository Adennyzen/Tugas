from flask import Flask, render_template, request
import xmlrpc.client
import pika
import json
import uuid


app = Flask(__name__)

RPC_SERVER_URL = "http://localhost:8000"
RABBITMQ_HOST = "localhost"
EXCHANGE_NAME = "order_events"


def publish_order_event(event: dict):
    """Publish event ke RabbitMQ secara asinkron (fire-and-forget)."""
    connection = pika.BlockingConnection(pika.ConnectionParameters(RABBITMQ_HOST))
    channel = connection.channel()
    channel.exchange_declare(exchange=EXCHANGE_NAME, exchange_type="fanout")
    channel.basic_publish(exchange=EXCHANGE_NAME, routing_key="", body=json.dumps(event))
    connection.close()


@app.route("/", methods=["GET"])
def index():
    return render_template("checkout.html", result=None)


@app.route("/checkout", methods=["POST"])
def checkout():
    item = request.form.get("item")
    amount = float(request.form.get("amount"))
    order_id = str(uuid.uuid4())[:8]

    # 1. Panggil Payment Service via RPC -- SINKRON, web menunggu balasan ini
    rpc_client = xmlrpc.client.ServerProxy(RPC_SERVER_URL)
    payment_result = rpc_client.validate_payment(order_id, amount)

    result = {"order_id": order_id, "item": item, "amount": amount, "payment": payment_result}

    # 2. Jika sukses, publish event -- ASINKRON, web TIDAK menunggu consumer
    if payment_result["status"] == "SUCCESS":
        publish_order_event({
            "order_id": order_id, "item": item, "amount": amount, "event": "order.paid"
        })
        result["notice"] = "Pembayaran sukses. Notifikasi & update stok diproses di belakang."
    else:
        result["notice"] = "Pembayaran gagal: " + payment_result.get("message", "")

    return render_template("checkout.html", result=result)


if __name__ == "__main__":
    app.run(debug=True, port=5000)
