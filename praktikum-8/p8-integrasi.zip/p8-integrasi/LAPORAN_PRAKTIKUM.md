# Laporan Praktikum Pertemuan 8

## Tujuan

Membangun sistem checkout web yang mengintegrasikan komunikasi antarpihak melalui XML-RPC sinkron dan RabbitMQ asinkron. Dokumen ini menyertai kode contoh modul serta empat latihan tambahannya. Identitas mahasiswa dapat ditambahkan sendiri sebelum dikumpulkan.

## Arsitektur dan alur

```text
Browser --HTTP form--> Order App (Flask, :5000)
                            |
                            +--XML-RPC sinkron--> Payment Service (:8000)
                            |<-----hasil validasi--+
                            |
                            +--publish order.paid--> RabbitMQ (:5672)
                                                      exchange order_events (fanout)
                                                        |                  |
                                                        v                  v
                                                queue notifikasi     queue stok
                                                        |                  |
                                                        v                  v
                                                consumer notifikasi  consumer stok
```

Pada latihan tambahan ada satu queue dan consumer keuangan lagi. Setiap consumer memiliki koneksi/proses sendiri. Walaupun judul modul menyebut IPC, contoh kode tidak menyediakan implementasi pipe/shared-memory lokal terpisah; kode konkret yang dipraktikkan adalah XML-RPC dan AMQP untuk komunikasi antarpihak/proses.

1. Browser mengirim `item` dan `amount` ke `/checkout`.
2. Order App membuat Order ID lalu memanggil `validate_payment` melalui XML-RPC.
3. Order App menunggu hasil validasi. Jumlah nol/negatif ditolak; jumlah positif memiliki peluang sukses sekitar 90%.
4. Hanya jika sukses, Order App membuka koneksi RabbitMQ dan mengirim JSON `order.paid` ke exchange `order_events` bertipe `fanout`.
5. Exchange menyalin event ke masing-masing queue consumer yang telah terikat.
6. Halaman menampilkan hasil. Consumer memproses event secara independen; tidak ada balasan consumer yang harus ditunggu oleh Order App.

## Skenario pengujian

| Skenario | Hasil yang diharapkan / diamati |
| --- | --- |
| Checkout positif hingga sukses | Halaman `SUCCESS`; JSON `order.paid` diterima broker; notifikasi dan stok menerima Order ID sama. |
| Pembayaran 0 | `FAILED`, jumlah tidak valid; tidak ada event. |
| Pembayaran negatif | `FAILED`, jumlah tidak valid; tidak ada event. |
| Consumer stok dimatikan | Notifikasi tetap menerima; consumer stok yang dimulai ulang tidak memperoleh event yang terlewat, tetapi menerima event baru. |

Hasil eksekusi aktual dan bukti terlampir ada di `HASIL_PENGUJIAN.md` serta `bukti/`. Kegagalan acak `Saldo tidak cukup` adalah bagian simulasi, bukan kesalahan instalasi.

## Jawaban analisis modul

### 1. Mengapa harus menunggu Payment Service, tetapi tidak consumer?

Pembayaran menentukan apakah checkout boleh dianggap berhasil. Order App memerlukan jawaban Payment Service sebelum menampilkan status dan mengirim `order.paid`. Karena itu panggilan RPC ada pada jalur sinkron request pengguna.

Notifikasi dan pengurangan stok contoh ini adalah pekerjaan lanjutan. Setelah event dipublish, masing-masing consumer dapat memprosesnya tanpa respons ke Order App. Lambatnya callback consumer tidak menjadi syarat selesainya HTTP request. Pada kode ini pemanggilan `pika.BlockingConnection` dan publish tetap berlangsung di dalam request, sehingga koneksi/publish ke broker masih dapat memperlambat atau menggagalkan respons. Yang tidak ditunggu adalah **pemrosesan oleh consumer**, bukan seluruh aktivitas jaringan RabbitMQ.

### 2. Jika publish ke RabbitMQ gagal, apa dampaknya dan penanganan andal?

Versi utama mengikuti kode modul tanpa `try/except`. Pembayaran mungkin sudah sukses, tetapi kegagalan koneksi/publish dapat menyebabkan HTTP 500, sehingga pengguna bingung dan berisiko membayar ulang. Pada kasus putus koneksi, pengirim juga belum tentu tahu apakah broker telah menerima pesan.

Latihan tambahan menangkap error, mempertahankan `SUCCESS` untuk pembayaran yang telah dinyatakan berhasil, lalu memberi tahu bahwa pengiriman event belum terkonfirmasi. Ini memperbaiki informasi pengguna, tetapi belum menjamin event akan terkirim: belum ada penyimpanan persisten atau retry.

Untuk sistem andal, catat order dan event dalam penyimpanan persisten dengan pola transactional outbox, kirim ulang lewat worker dengan retry/backoff, pakai exchange/queue durable dan pesan persistent, aktifkan publisher confirms, serta buat consumer idempoten berdasarkan event/order ID. Gunakan manual acknowledgement setelah efek bisnis benar-benar tersimpan. Konfirmasi broker menjamin penerimaan sesuai mekanismenya, bukan selesainya seluruh consumer. Saat status RPC tidak dapat dipastikan, gunakan idempotency key dan rekonsiliasi; jangan langsung mengulang pembayaran.

### 3. Fanout dengan dua queue dibanding satu queue dibagi dua consumer

Dengan `fanout` dan **queue berbeda**, setiap queue memperoleh salinan pesan; notifikasi dan stok masing-masing melakukan pekerjaannya atas order yang sama. Keduanya harus menerima setiap order sukses.

Dengan **satu queue** dibagi dua consumer, consumer bersaing mengambil pesan. Dalam kondisi setara pembagian sering tampak round-robin, tetapi prefetch, acknowledgement, dan kecepatan consumer memengaruhinya. Umumnya satu pesan diberikan ke satu consumer, bukan keduanya. Pola ini cocok untuk beberapa worker dengan pekerjaan yang sama, bukan notifikasi dan stok yang membutuhkan efek berbeda.

### 4. Mengapa event hilang ketika salah satu consumer mati?

`queue_declare(queue="", exclusive=True)` membuat queue bernama otomatis yang dimiliki satu koneksi. Ketika koneksi consumer ditutup, queue dihapus. Consumer baru membuat queue baru; event yang dikirim ketika queue lamanya tidak ada tidak disimpan untuk consumer tersebut. Exchange bukan tempat menyimpan backlog tanpa queue yang terikat. `auto_ack=True` pada kedua consumer utama juga berarti pesan tidak menunggu penyelesaian callback sebelum dianggap terkirim.

Jika membutuhkan backlog saat consumer offline, gunakan queue bernama tetap yang durable, binding yang sudah tersedia, pesan persistent, broker yang dikonfigurasi untuk durability, dan manual acknowledgement. Hal itu merupakan pengembangan dari contoh, bukan perilaku kode utama.

## Jawaban latihan mandiri

1. **Metode pembayaran:** form dan RPC versi tambahan memakai `metode_pembayaran`. Server menerima `transfer_bank`, `e_wallet`, dan `kartu`; input lain menghasilkan `FAILED` tanpa publish.
2. **Consumer laporan keuangan:** `consumer_keuangan.py` membuat queue sendiri pada exchange yang sama dan menambahkan JSON berisi waktu UTC, Order ID, barang, nominal, metode, dan event ke `logs/laporan_keuangan.log`. Manual ack dilakukan setelah penulisan file. Queue masih eksklusif seperti contoh; ini belum menjamin ketahanan terhadap seluruh jenis crash.
3. **Penanganan error:** `try/except` melindungi panggilan RPC dan publish. Koneksi diberi timeout. Gangguan RPC menghasilkan status `UNKNOWN`, sedangkan gangguan broker sesudah pembayaran sukses tidak mengubah status pembayaran menjadi gagal. Validasi input juga menangani angka tidak sah.
4. **Riwayat order:** list `order_history` menyimpan maksimal 50 hasil terbaru dan dirender pada halaman checkout. Data hilang saat proses Flask/reloader dimulai ulang; bukan riwayat persisten atau per pengguna.

## Batasan sesuai konteks praktikum

- Seluruh pembayaran, notifikasi, dan update stok adalah simulasi; tidak terhubung ke bank, layanan pesan, atau database stok.
- Kode utama sengaja mempertahankan probabilitas pembayaran, debug server, queue sementara, auto-ack, dan tidak adanya penanganan error sebagaimana modul.
- Event bisa diproses consumer sebelum maupun sesudah respons web diterima. Asinkron tidak menjamin urutan waktu log di layar; yang dibuktikan adalah tidak adanya keharusan menunggu balasan consumer.
- Tangkapan layar dan log adalah hasil pengujian di lingkungan Linux. Perintah laptop Windows/macOS disertakan sebagai panduan; pengujian langsung pada OS tersebut belum dilakukan.
