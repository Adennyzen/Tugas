from flask import Flask, render_template, request
import json
import math
import pika
import uuid
import xmlrpc.client


app = Flask(__name__)
RPC_SERVER_URL = "http://localhost:8000"
RABBITMQ_HOST = "localhost"
EXCHANGE_NAME = "order_events"
order_history = []


class TimeoutTransport(xmlrpc.client.Transport):
    def make_connection(self, host):
        connection = super().make_connection(host)
        connection.timeout = 5
        return connection


def publish_order_event(event):
    parameters = pika.ConnectionParameters(
        RABBITMQ_HOST, connection_attempts=1, socket_timeout=3,
        stack_timeout=5, blocked_connection_timeout=5,
    )
    connection = pika.BlockingConnection(parameters)
    try:
        channel = connection.channel()
        channel.exchange_declare(exchange=EXCHANGE_NAME, exchange_type="fanout")
        channel.basic_publish(exchange=EXCHANGE_NAME, routing_key="", body=json.dumps(event))
    finally:
        if connection.is_open:
            connection.close()


@app.route("/", methods=["GET"])
def index():
    return render_template("checkout.html", result=None, history=list(reversed(order_history)))


@app.route("/checkout", methods=["POST"])
def checkout():
    item = (request.form.get("item") or "").strip()
    metode = request.form.get("metode_pembayaran", "")
    result = {
        "order_id": str(uuid.uuid4())[:8], "item": item,
        "amount": 0, "metode_pembayaran": metode,
        "payment": {"status": "FAILED", "message": ""},
        "notice": "", "event_status": "Tidak dikirim",
    }
    try:
        amount = float(request.form.get("amount", ""))
        if not item or not math.isfinite(amount):
            raise ValueError("Data checkout tidak valid")
        result["amount"] = amount
    except (TypeError, ValueError, OverflowError):
        result["payment"]["message"] = "Isi nama barang dan jumlah pembayaran dengan benar"
        result["notice"] = result["payment"]["message"]
        return finish_order(result)

    try:
        with xmlrpc.client.ServerProxy(RPC_SERVER_URL, transport=TimeoutTransport()) as rpc:
            result["payment"] = rpc.validate_payment(result["order_id"], amount, metode)
    except (OSError, xmlrpc.client.Error):
        app.logger.exception("Payment Service tidak dapat dihubungi")
        result["payment"] = {"status": "UNKNOWN", "message": "Status pembayaran belum dapat dipastikan"}
        result["notice"] = "Payment Service tidak dapat dihubungi. Periksa layanan dan status pembayaran sebelum mencoba lagi."
        return finish_order(result)

    if result["payment"]["status"] == "SUCCESS":
        try:
            publish_order_event({
                "order_id": result["order_id"], "item": item, "amount": amount,
                "metode_pembayaran": metode, "event": "order.paid",
            })
        except (pika.exceptions.AMQPError, OSError):
            app.logger.exception("Publish order.paid gagal")
            result["event_status"] = "Belum terkonfirmasi"
            result["notice"] = (
                "Pembayaran berhasil, tetapi pengiriman notifikasi dan update stok belum terkonfirmasi. "
                "Periksa RabbitMQ. Jangan melakukan pembayaran ulang. "
                "Contoh ini belum memiliki mekanisme pengiriman ulang otomatis."
            )
        else:
            result["event_status"] = "Dipublish"
            result["notice"] = "Pembayaran sukses. Notifikasi & update stok diproses di belakang."
    else:
        result["notice"] = "Pembayaran gagal: " + result["payment"].get("message", "")
    return finish_order(result)


def finish_order(result):
    order_history.append(result)
    del order_history[:-50]
    return render_template("checkout.html", result=result, history=list(reversed(order_history)))


if __name__ == "__main__":
    app.run(debug=True, port=5000)
