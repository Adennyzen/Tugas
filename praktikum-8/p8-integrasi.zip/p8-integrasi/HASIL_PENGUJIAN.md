# Hasil pengujian aktual

## Lingkungan

- Python 3.12.14, Linux x86_64.
- Flask 3.1.3, Pika 1.4.4. Versi lengkap ada di `requirements-tested.txt`.
- RabbitMQ 3.13.7, image resmi Docker `rabbitmq:3-management`.
- Browser Chromium headless melalui Playwright.
- Pengujian langsung dilakukan di Linux. Windows/macOS belum diuji langsung.

## Hasil

**44 pemeriksaan integrasi lulus** dengan XML-RPC, Flask, dan RabbitMQ nyata; tidak memakai broker tiruan. **14 pemeriksaan browser lulus.** Total 58 pemeriksaan, tanpa kegagalan pada run yang dilampirkan. Kedua proses uji selesai dengan exit code 0. Pemeriksaan dependensi `pip check` juga lulus.

### Integrasi — 44 pemeriksaan

Versi utama: layanan siap, halaman HTTP 200, pembayaran nol/negatif ditolak tanpa publish, transaksi sukses menghasilkan payload `order.paid`, kedua consumer menerima Order ID yang sama, notifikasi tetap berjalan saat consumer stok mati, consumer stok dapat direstart dan menerima event baru, serta event selama consumer offline tidak diputar ulang.

Versi tambahan: seluruh alur dasar di atas, tiga metode pembayaran diterima, metode tidak dikenal ditolak, input angka tidak sah ditangani, consumer ketiga menulis laporan keuangan, riwayat order tampil, RPC mati menghasilkan pesan ramah berstatus `UNKNOWN`, dan broker mati setelah pembayaran sukses tidak membuat status pembayaran berubah menjadi gagal. Broker dinyalakan kembali dan koneksi AMQP diverifikasi pulih.

Perintah aktual di lingkungan pengujian (interpreter venv digunakan):

```text
python pengujian/uji_integrasi.py --container p8-rabbitmq-test --output /workspace/scratch/p8-hasil-integrasi.json
```

Nama container khusus pengujian adalah `p8-rabbitmq-test`; panduan laptop menggunakan `rabbitmq`. Daftar 44 pemeriksaan tersimpan dalam `bukti/hasil-uji-integrasi.json`. Path direktori sementara dalam JSON merujuk mesin pengujian; salinan log yang bisa dibaca dari paket tersedia di `bukti/log-integrasi/`.

### Browser — 14 pemeriksaan

- Kedua versi: halaman HTTP 200, judul dan form tampil, submit nol menampilkan `FAILED`, submit positif hingga sukses menampilkan `SUCCESS`, tanpa page script error.
- Versi utama: CSS mempertahankan `max-width: 520px` sesuai modul.
- Versi tambahan: tiga pilihan metode, riwayat mencakup gagal/sukses, tampilan pada viewport ponsel 390 × 844 tidak meluber secara horizontal.

Daftar lengkap ada di `bukti/hasil-uji-browser.json`. Tangkapan layar:

- `bukti/modul-form.png`, `modul-gagal.png`, `modul-sukses.png`.
- `bukti/tambahan-form.png`, `tambahan-gagal.png`, `tambahan-sukses.png`, `tambahan-ponsel.png`.

Log browser disertakan di `bukti/*-browser-*.log`. Contoh catatan keuangan dari pengujian integrasi ada di `bukti/contoh-laporan-keuangan.log`. File log aplikasi latihan sengaja tidak disertakan sebagai data aktif; saat Anda menjalankannya, aplikasi membuat log baru sendiri.

## Penafsiran hasil

- Pembayaran positif bisa gagal acak sekitar 10%, sesuai modul. Tes mengulang transaksi positif sampai mendapatkan sukses, dengan batas 40 percobaan; algoritme sumber tidak diubah.
- Hilangnya event bagi consumer yang offline adalah hasil yang diharapkan untuk queue eksklusif, bukan kegagalan tes.
- Traceback pada log uji gangguan RPC/RabbitMQ versi tambahan merupakan log diagnosis dari error yang sengaja dipicu; respons web tetap ditangani dan pemeriksaannya lulus.
- Versi utama mengikuti kode modul dan belum menangani layanan mati dengan pesan ramah. Penanganan tersebut tersedia di versi latihan. Tidak ada klaim bahwa versi utama menangani gangguan layanan.
- Menjalankan ZIP di laptop tetap memerlukan instalasi Python, Docker, dan dependensi. Virtual environment, binary RabbitMQ, dan image Docker tidak dibundel; pemasangan awal memerlukan internet.
