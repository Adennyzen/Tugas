from xmlrpc.server import SimpleXMLRPCServer
import random


def validate_payment(order_id, amount):
    """Simulasi validasi pembayaran. Dipanggil via RPC, harus membalas sinkron."""
    print(f"[Payment Service] Memvalidasi order {order_id} sebesar Rp{amount:,.0f}")

    if amount <= 0:
        return {"status": "FAILED", "message": "Jumlah pembayaran tidak valid"}

    # Simulasi: 90% transaksi berhasil
    saldo_cukup = random.random() > 0.1
    if saldo_cukup:
        return {"status": "SUCCESS", "message": "Pembayaran berhasil divalidasi", "order_id": order_id}
    return {"status": "FAILED", "message": "Saldo tidak cukup"}


if __name__ == "__main__":
    server = SimpleXMLRPCServer(("localhost", 8000), allow_none=True)
    server.register_function(validate_payment, "validate_payment")
    print("[Payment Service] RPC server berjalan di port 8000...")
    server.serve_forever()
