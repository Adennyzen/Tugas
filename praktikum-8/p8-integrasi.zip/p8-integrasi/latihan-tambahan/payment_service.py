from xmlrpc.server import SimpleXMLRPCServer
import math
import random


METODE_DIKENAL = {"transfer_bank", "e_wallet", "kartu"}


def validate_payment(order_id, amount, metode_pembayaran):
    print(f"[Payment Service] Memvalidasi order {order_id} sebesar Rp{amount:,.0f} via {metode_pembayaran}")
    if metode_pembayaran not in METODE_DIKENAL:
        return {"status": "FAILED", "message": "Metode pembayaran tidak dikenal"}
    if not math.isfinite(amount) or amount <= 0:
        return {"status": "FAILED", "message": "Jumlah pembayaran tidak valid"}
    if random.random() > 0.1:
        return {"status": "SUCCESS", "message": "Pembayaran berhasil divalidasi", "order_id": order_id}
    return {"status": "FAILED", "message": "Saldo tidak cukup"}


if __name__ == "__main__":
    server = SimpleXMLRPCServer(("localhost", 8000), allow_none=True)
    server.register_function(validate_payment, "validate_payment")
    print("[Payment Service] RPC server berjalan di port 8000...")
    server.serve_forever()
