import pika, json


EXCHANGE_NAME = "order_events"


def callback(ch, method, properties, body):
    event = json.loads(body)
    print(f"[Notifikasi] Mengirim notifikasi: pesanan {event['order_id']} ({event['item']}) sudah dibayar.")


connection = pika.BlockingConnection(pika.ConnectionParameters("localhost"))
channel = connection.channel()
channel.exchange_declare(exchange=EXCHANGE_NAME, exchange_type="fanout")
queue = channel.queue_declare(queue="", exclusive=True)
channel.queue_bind(exchange=EXCHANGE_NAME, queue=queue.method.queue)

print("[Notifikasi] Menunggu event order...")
channel.basic_consume(queue=queue.method.queue, on_message_callback=callback, auto_ack=True)
channel.start_consuming()
