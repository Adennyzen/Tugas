"""Uji integrasi dengan RPC, Flask, dan RabbitMQ nyata. Lihat README sebelum menjalankan."""
import argparse
import json
import os
from pathlib import Path
import re
import signal
import socket
import subprocess
import sys
import tempfile
import time
from urllib.error import URLError
from urllib.parse import urlencode
from urllib.request import urlopen
import xmlrpc.client

import pika


ROOT = Path(__file__).resolve().parents[1]
RESULTS = []
PROCESSES = []
LOGS = Path(tempfile.mkdtemp(prefix="p8-integrasi-test-"))


def check(condition, label):
    if not condition:
        raise AssertionError(label)
    RESULTS.append(label)
    print("LULUS:", label, flush=True)


def wait_until(predicate, timeout=20):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if predicate():
            return True
        time.sleep(0.1)
    return False


def start(folder, script, name):
    log = LOGS / (name + ".log")
    env = {**os.environ, "PYTHONUNBUFFERED": "1", "PYTHONDONTWRITEBYTECODE": "1"}
    with log.open("wb") as stream:
        p = subprocess.Popen([sys.executable, "-u", script], cwd=folder, env=env,
                             stdout=stream, stderr=subprocess.STDOUT,
                             start_new_session=(os.name != "nt"))
    PROCESSES.append(p)
    return p, log


def stop(p):
    if p.poll() is not None:
        return
    if os.name == "nt":
        subprocess.run(["taskkill", "/PID", str(p.pid), "/T", "/F"], capture_output=True)
    else:
        os.killpg(p.pid, signal.SIGTERM)
    try:
        p.wait(timeout=10)
    except subprocess.TimeoutExpired:
        p.kill()
        p.wait(timeout=5)


def has_text(log, text):
    return log.exists() and text in log.read_text(encoding="utf-8", errors="replace")


def get_page():
    try:
        with urlopen("http://127.0.0.1:5000/", timeout=2) as response:
            return response.read().decode()
    except (URLError, TimeoutError, ConnectionError):
        return ""


def checkout(amount, method=None, item="Buku Praktikum"):
    data = {"item": item, "amount": str(amount)}
    if method is not None:
        data["metode_pembayaran"] = method
    with urlopen("http://127.0.0.1:5000/checkout", data=urlencode(data).encode(), timeout=15) as response:
        assert response.status == 200
        return response.read().decode()


def successful_checkout(method=None):
    # Randomisasi 90% tetap sama seperti modul; jangan mengubah source agar tes lulus.
    for _ in range(40):
        html = checkout(50000, method)
        match = re.search(r"<b>Order ID:</b>\s*([0-9a-f-]{8})", html)
        if "<b>Status Pembayaran:</b> SUCCESS" in html:
            assert match
            return match.group(1), html
        assert "Saldo tidak cukup" in html
    raise AssertionError("40 percobaan tidak menghasilkan pembayaran sukses")


def broker_connection():
    return pika.BlockingConnection(pika.ConnectionParameters(
        "localhost", connection_attempts=1, socket_timeout=2, stack_timeout=4))


def broker_ready():
    try:
        connection = broker_connection()
        connection.close()
        return True
    except (pika.exceptions.AMQPError, OSError):
        return False


def run_variant(extended=False):
    name = "tambahan" if extended else "modul"
    folder = ROOT / "latihan-tambahan" if extended else ROOT
    method = "transfer_bank" if extended else None
    payment, payment_log = start(folder, "payment_service.py", name + "-payment")
    check(wait_until(lambda: has_text(payment_log, "RPC server berjalan")), name + ": RPC aktif")
    notification, notification_log = start(folder, "consumer_notifikasi.py", name + "-notifikasi")
    stock, stock_log = start(folder, "consumer_stok.py", name + "-stok")
    check(wait_until(lambda: has_text(notification_log, "Menunggu event") and has_text(stock_log, "Menunggu event")),
          name + ": dua consumer siap sebelum publish")
    finance = None
    if extended:
        finance, finance_log = start(folder, "consumer_keuangan.py", name + "-keuangan")
        check(wait_until(lambda: has_text(finance_log, "Menunggu event")), name + ": consumer keuangan aktif")
    web, web_log = start(folder, "order_app.py", name + "-web")
    check(wait_until(lambda: "Checkout Pesanan" in get_page()), name + ": halaman checkout HTTP 200")

    connection = broker_connection()
    channel = connection.channel()
    channel.exchange_declare(exchange="order_events", exchange_type="fanout")
    audit = channel.queue_declare(queue="", exclusive=True).method.queue
    channel.queue_bind(exchange="order_events", queue=audit)
    for amount in (0, -1000):
        html = checkout(amount, method)
        check("<b>Status Pembayaran:</b> FAILED" in html and "Jumlah pembayaran tidak valid" in html,
              f"{name}: jumlah {amount} ditolak")
        delivery, _, _ = channel.basic_get(audit, auto_ack=True)
        check(delivery is None, f"{name}: jumlah {amount} tidak mempublish event")

    if extended:
        html = checkout(50000, "tidak_dikenal")
        check("Metode pembayaran tidak dikenal" in html and "<b>Status Pembayaran:</b> FAILED" in html,
              "tambahan: metode tidak dikenal ditolak melalui RPC")
        delivery, _, _ = channel.basic_get(audit, auto_ack=True)
        check(delivery is None, "tambahan: metode ditolak tidak mempublish event")
        for invalid in ("abc", "nan", "inf"):
            html = checkout(invalid, method)
            check("Isi nama barang dan jumlah pembayaran dengan benar" in html,
                  "tambahan: input tidak valid ditangani (" + invalid + ")")

    order_id, html = successful_checkout(method)
    check("Notifikasi &amp; update stok diproses di belakang." in html, name + ": checkout sukses di web")
    delivery, _, body = channel.basic_get(audit, auto_ack=True)
    event = json.loads(body) if delivery else {}
    check(event.get("order_id") == order_id and event.get("event") == "order.paid" and event.get("amount") == 50000,
          name + ": payload order.paid diterima RabbitMQ")
    check(wait_until(lambda: has_text(notification_log, order_id) and has_text(stock_log, order_id)),
          name + ": satu event diterima kedua consumer independen")

    if extended:
        file = folder / "logs" / "laporan_keuangan.log"
        check(wait_until(lambda: file.exists() and order_id in file.read_text(encoding="utf-8")),
              "tambahan: consumer ketiga mencatat transaksi ke file")
        check("Riwayat Order" in get_page() and order_id in get_page(), "tambahan: riwayat order tampil pada GET berikutnya")
        with xmlrpc.client.ServerProxy("http://localhost:8000") as rpc:
            for supported in ("transfer_bank", "e_wallet", "kartu"):
                result = rpc.validate_payment("uji-metode", 10000, supported)
                check(result.get("message") != "Metode pembayaran tidak dikenal",
                      "tambahan: RPC menerima metode " + supported)

    stop(stock)
    order_offline, _ = successful_checkout(method)
    check(wait_until(lambda: has_text(notification_log, order_offline)), name + ": notifikasi tetap menerima saat stok mati")
    stock, restarted_log = start(folder, "consumer_stok.py", name + "-stok-restart")
    check(wait_until(lambda: has_text(restarted_log, "Menunggu event")), name + ": consumer stok dapat dimulai ulang")
    next_order, _ = successful_checkout(method)
    check(wait_until(lambda: has_text(restarted_log, next_order)), name + ": consumer restart menerima event baru")
    check(not has_text(restarted_log, order_offline), name + ": event saat consumer offline tidak diputar ulang (queue eksklusif)")
    connection.close()

    if extended:
        stop(payment)
        html = checkout(50000, method)
        check("Payment Service tidak dapat dihubungi" in html and "<b>Status Pembayaran:</b> UNKNOWN" in html,
              "tambahan: RPC down menampilkan pesan ramah tanpa HTTP 500")
        payment, _ = start(folder, "payment_service.py", name + "-payment-restart")
        check(wait_until(lambda: has_text(LOGS / (name + "-payment-restart.log"), "RPC server berjalan")),
              "tambahan: Payment Service dapat dimulai ulang")

    for p in [web, stock, notification, payment, finance]:
        if p:
            stop(p)


def broker_outage(container):
    folder = ROOT / "latihan-tambahan"
    payment, log = start(folder, "payment_service.py", "outage-payment")
    assert wait_until(lambda: has_text(log, "RPC server berjalan"))
    web, _ = start(folder, "order_app.py", "outage-web")
    assert wait_until(lambda: "Checkout Pesanan" in get_page())
    try:
        subprocess.run(["docker", "stop", container], check=True, capture_output=True)
        _, html = successful_checkout("transfer_bank")
        check("pengiriman notifikasi dan update stok belum terkonfirmasi" in html and "Jangan melakukan pembayaran ulang" in html,
              "tambahan: RabbitMQ down ditangani tanpa menyatakan pembayaran gagal")
        check("Belum terkonfirmasi" in get_page(), "tambahan: kegagalan publish dicatat dalam riwayat")
    finally:
        stop(web)
        stop(payment)
        subprocess.run(["docker", "start", container], check=True, capture_output=True)
        check(wait_until(broker_ready, 60), "RabbitMQ pulih setelah uji outage")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--container", help="Opsional: nama container RabbitMQ lokal milik Anda untuk uji stop/start broker")
    parser.add_argument("--output", help="Simpan laporan hasil JSON ke lokasi ini")
    args = parser.parse_args()
    for port in (5000, 8000):
        with socket.socket() as s:
            if s.connect_ex(("127.0.0.1", port)) == 0:
                raise SystemExit(f"Port {port} dipakai. Hentikan aplikasi praktikum Anda sebelum menjalankan tes.")
    if not broker_ready():
        raise SystemExit("RabbitMQ belum siap di localhost:5672. Jalankan broker dahulu.")
    try:
        run_variant()
        run_variant(extended=True)
        if args.container:
            broker_outage(args.container)
        else:
            print("TIDAK DIJALANKAN: uji RabbitMQ down (berikan --container untuk mengaktifkan).")
        report = {"passed": len(RESULTS), "checks": RESULTS, "broker_outage_test": bool(args.container), "logs": str(LOGS)}
        if args.output:
            Path(args.output).write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"SELESAI: {len(RESULTS)} pemeriksaan lulus. Log: {LOGS}")
    finally:
        for process in reversed(PROCESSES):
            stop(process)


if __name__ == "__main__":
    main()
