# Praktikum Pertemuan 8 — Integrasi RPC & Message Queue

Proyek mengikuti PDF **Modul Praktikum Pertemuan 8: Integrasi IPC, RPC, dan Message Queue (Web App)** yang diberikan. Kode utama di folder ini mengikuti bagian 3.1–3.6: nama file, isi form, CSS, port, algoritme pembayaran, exchange `fanout`, dan kedua consumer dipertahankan. Baris kode yang terpotong oleh tata letak PDF disatukan agar dapat dijalankan.

**Untuk versi sesuai contoh modul, jalankan file pada folder utama ini.** Hasil empat latihan mandiri halaman 10 tersedia terpisah di `latihan-tambahan/`; jangan menjalankan kedua versi bersamaan karena menggunakan port yang sama.

## Isi paket

```text
p8-integrasi/
  payment_service.py             # RPC server, port 8000
  order_app.py                   # Flask + RPC client + publisher, port 5000
  consumer_notifikasi.py         # Consumer pertama
  consumer_stok.py               # Consumer kedua
  templates/checkout.html        # HTML dan CSS sesuai modul
  requirements.txt              # flask dan pika, sesuai modul
  requirements-tested.txt       # Versi dependensi saat pengujian
  README.md                     # Panduan ini
  LAPORAN_PRAKTIKUM.md           # Analisis dan pembahasan skenario
  HASIL_PENGUJIAN.md             # Hasil aktual, lingkungan, dan batasan
  pengujian/uji_integrasi.py     # Tes dengan layanan nyata
  bukti/                        # Log, hasil tes JSON, dan tangkapan layar
  modul/                        # Salinan PDF praktikum yang diberikan
  latihan-tambahan/             # Jawaban latihan 1–4, versi terpisah
```

## 1. Persiapan laptop

Instal **Python 3.10 atau lebih baru** dan **Docker Desktop** (Windows/macOS) atau Docker Engine (Linux). Aktifkan Docker dan pastikan perintah `docker version` menampilkan bagian Client dan Server. Docker Desktop Windows memerlukan dukungan virtualisasi/WSL 2 sesuai petunjuk instalasinya. Koneksi internet diperlukan untuk instalasi awal.

Ekstrak ZIP dahulu; jangan menjalankan file dari dalam aplikasi pembuka ZIP. Buka terminal di folder `p8-integrasi` yang berisi `order_app.py`. Simpan semua file bersama folder `templates`.

### Windows — Command Prompt (CMD)

```bat
py -m venv venv
venv\Scripts\activate.bat
python -m pip install -r requirements.txt
```

Jika `py` tidak dikenali tetapi `python --version` berfungsi, gunakan `python -m venv venv`. Bila memakai PowerShell dan aktivasi diblokir, gunakan CMD atau jalankan interpreter langsung tanpa mengubah kebijakan sistem:

```powershell
.\venv\Scripts\python.exe -m pip install -r requirements.txt
.\venv\Scripts\python.exe payment_service.py
```

Pola interpreter langsung yang sama berlaku untuk file lainnya di terminal masing-masing.

### macOS / Linux

```bash
python3 -m venv venv
source venv/bin/activate
python -m pip install -r requirements.txt
```

Jika Linux melaporkan modul `venv` tidak tersedia, instal paket `python3-venv` melalui package manager distribusi Anda. Untuk memasang versi dependensi yang digunakan saat pengujian, ganti perintah instalasi dengan `python -m pip install -r requirements-tested.txt`.

## 2. Jalankan RabbitMQ — Terminal 1

Sesuai perintah di modul (ketik dalam **satu baris**):

```bash
docker run -d --name rabbitmq -p 5672:5672 -p 15672:15672 rabbitmq:3-management
```

Perintah ini cukup sekali saat membuat container. Jika container sudah ada, gunakan:

```bash
docker start rabbitmq
```

Tunggu broker siap; periksa:

```bash
docker exec rabbitmq rabbitmq-diagnostics -q ping
```

Hasil siap berbunyi `Ping succeeded`. Dashboard tersedia di **http://localhost:15672**, username **guest**, password **guest**. Ini akun bawaan RabbitMQ lokal untuk praktikum; jangan gunakan konfigurasi tersebut sebagai layanan publik. Jika proses startup masih berlangsung, lihat `docker logs rabbitmq` dan periksa lagi setelah siap.

## 3. Jalankan aplikasi — Terminal 2 sampai 5

Di **setiap terminal baru**, masuk ke folder `p8-integrasi` dan aktifkan venv yang sama. CMD: `venv\Scripts\activate.bat`. macOS/Linux: `source venv/bin/activate`. Lalu jalankan satu proses per terminal, sesuai urutan:

| Terminal | Perintah | Tanda siap |
| --- | --- | --- |
| 2 | `python -u payment_service.py` | RPC server berjalan di port 8000 |
| 3 | `python -u consumer_notifikasi.py` | Notifikasi: Menunggu event order |
| 4 | `python -u consumer_stok.py` | Stok: Menunggu event order |
| 5 | `python -u order_app.py` | Running on http://127.0.0.1:5000 |

Opsi `-u` hanya membuat log terminal langsung terlihat; modul memakai `python nama_file.py`, yang menjalankan kode sama. Pastikan kedua consumer sudah siap **sebelum** melakukan checkout karena queue bersifat eksklusif dan sementara.

Buka **http://localhost:5000** di browser laptop. Isi **Nama Barang** misalnya `Buku Praktikum`, **Jumlah Pembayaran (Rp)** misalnya `50000`, lalu klik **Bayar Sekarang**.

- Sukses: hasil hijau, status `SUCCESS`, Order ID, serta pesan notifikasi/update stok diproses di belakang.
- Periksa log Payment Service, Notifikasi, dan Stok; semua merujuk Order ID yang sama.
- Sekitar 10% pembayaran positif akan `FAILED` dengan pesan `Saldo tidak cukup`, sesuai `random.random() > 0.1` di modul. Ulangi checkout dengan data positif untuk mengamati alur sukses; nilai positif tidak menjamin sukses setiap kali.

## 4. Uji tiga skenario modul

1. **Jumlah wajar:** gunakan `50000`. Saat `SUCCESS`, kedua consumer harus mencetak Order ID yang sama.
2. **Nol dan negatif:** gunakan `0`, lalu `-1000`. Status harus `FAILED`, pesan `Jumlah pembayaran tidak valid`, dan tidak ada event baru. Di dashboard RabbitMQ, pantau counter pesan pada queue; queue biasanya kosong karena pesan langsung dikonsumsi, sehingga panjang queue saja bukan bukti tidak ada publish. Bandingkan counter masuk dan log consumer sebelum/sesudah.
3. **Consumer mati:** tekan Ctrl+C di terminal consumer stok, lakukan checkout sampai sukses, lalu nyalakan consumer stok kembali. Notifikasi tetap menerima order tadi. Consumer stok yang dimulai ulang menerima order berikutnya, tetapi tidak menerima ulang order selama ia mati: queue eksklusif lama dihapus saat koneksinya ditutup.

## 5. Menjalankan empat latihan tambahan

Hentikan keempat proses Python utama dengan Ctrl+C terlebih dahulu. RabbitMQ boleh tetap berjalan. Di setiap terminal baru, dari root `p8-integrasi`, aktifkan venv, kemudian masuk ke `latihan-tambahan`:

```bash
cd latihan-tambahan
```

Jalankan masing-masing dalam terminal terpisah:

```text
python -u payment_service.py
python -u consumer_notifikasi.py
python -u consumer_stok.py
python -u consumer_keuangan.py
python -u order_app.py
```

Buka alamat web yang sama, http://localhost:5000. Versi ini menambahkan:

1. Pilihan metode pembayaran `transfer_bank`, `e_wallet`, `kartu`; RPC menolak metode lain.
2. Consumer keuangan yang menambahkan satu JSON per transaksi ke `latihan-tambahan/logs/laporan_keuangan.log`. File/folder dibuat otomatis setelah menerima event.
3. Pesan ramah saat RPC atau RabbitMQ tidak tersedia. Jika RPC tidak dapat dihubungi, status ditampilkan `UNKNOWN`. Jika pembayaran sukses tetapi publish gagal, status pembayaran tetap `SUCCESS`, sedangkan status event `Belum terkonfirmasi`. Tidak ada retry otomatis dalam contoh ini.
4. Riwayat maksimal 50 order di memori, termasuk gagal dan gangguan layanan; hilang saat Flask direstart. Semua pengguna proses Flask yang sama berbagi riwayat ini.

Tidak ada basis data, pembayaran sungguhan, email/WhatsApp sungguhan, atau perubahan inventaris sungguhan. Sesuai modul, notifikasi dan pengurangan stok adalah simulasi melalui log terminal.

## 6. Tes integrasi otomatis (opsional)

Hentikan **seluruh proses Python praktikum** agar port 5000 dan 8000 bebas. RabbitMQ harus tetap berjalan. Dari root `p8-integrasi` dengan venv aktif:

```bash
python pengujian/uji_integrasi.py
```

Tes menjalankan kedua versi secara bergantian, memakai RabbitMQ nyata, lalu membersihkan proses yang dibuatnya. Log disimpan di direktori sementara yang dicetak di akhir. Consumer keuangan juga menambah catatan pada file log latihan. Tes bawaan ini tidak membutuhkan Playwright.

Untuk turut menguji RabbitMQ mati/pulih, berikan nama container lokal Anda:

```bash
python pengujian/uji_integrasi.py --container rabbitmq --output hasil-uji.json
```

Perintah terakhir **menghentikan dan menyalakan kembali container tersebut**. Jalankan hanya pada RabbitMQ lokal khusus praktikum, bukan layanan bersama. Tanpa opsi `--container`, uji gangguan broker ditandai tidak dijalankan.

## 7. Menghentikan / menjalankan kembali

- Ctrl+C pada masing-masing terminal Python.
- `docker stop rabbitmq` untuk menghentikan RabbitMQ.
- Sesi berikutnya: `docker start rabbitmq`, tunggu siap, aktifkan venv, jalankan kembali empat proses Python (atau lima untuk latihan tambahan).
- Jangan menjalankan `docker run --name rabbitmq ...` lagi jika container dengan nama itu sudah ada.

## Pemecahan masalah

| Gejala | Langkah |
| --- | --- |
| `ModuleNotFoundError: flask` / `pika` | Aktifkan venv di terminal itu, lalu `python -m pip install -r requirements.txt`. |
| `AMQPConnectionError` | Pastikan Docker dan RabbitMQ aktif, tunggu `Ping succeeded`, lalu mulai ulang consumer. |
| `ConnectionRefusedError` ke port 8000 | Jalankan Payment Service sebelum Order App. |
| `Address already in use` / `WinError 10048` | Hentikan proses lama yang Anda jalankan di port 5000/8000; jangan jalankan versi utama dan latihan bersamaan. macOS kadang memakai port 5000 untuk AirPlay Receiver; nonaktifkan layanan itu sementara melalui pengaturan sistem jika diperlukan. |
| `Conflict. container name rabbitmq is already in use` | Gunakan `docker start rabbitmq`. |
| `Internal Server Error` saat layanan mati pada versi utama | Ini perilaku contoh asli yang belum memiliki `try/except`; gunakan versi latihan untuk penanganan error. |
| Halaman tidak berubah setelah pindah versi | Pastikan seluruh proses versi lama sudah berhenti; muat ulang halaman. |
| Consumer yang direstart tidak menerima order lama | Sesuai sifat queue eksklusif contoh ini; bukan kegagalan instalasi. |

Contoh memakai Flask debug server untuk praktikum lokal, sesuai modul. Penjelasan keterbatasan dan rancangan yang lebih andal ada di `LAPORAN_PRAKTIKUM.md`.
