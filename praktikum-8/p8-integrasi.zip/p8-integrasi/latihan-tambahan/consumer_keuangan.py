from datetime import datetime, timezone
from pathlib import Path
import json
import pika


EXCHANGE_NAME = "order_events"
LOG_FILE = Path(__file__).resolve().parent / "logs" / "laporan_keuangan.log"


def callback(ch, method, properties, body):
    event = json.loads(body)
    record = {"waktu_utc": datetime.now(timezone.utc).isoformat(), **event}
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with LOG_FILE.open("a", encoding="utf-8") as log:
        log.write(json.dumps(record, ensure_ascii=False) + "\n")
    ch.basic_ack(delivery_tag=method.delivery_tag)
    print(f"[Keuangan] Order {event['order_id']} dicatat ke {LOG_FILE}")


connection = pika.BlockingConnection(pika.ConnectionParameters("localhost"))
channel = connection.channel()
channel.exchange_declare(exchange=EXCHANGE_NAME, exchange_type="fanout")
queue = channel.queue_declare(queue="", exclusive=True)
channel.queue_bind(exchange=EXCHANGE_NAME, queue=queue.method.queue)
channel.basic_qos(prefetch_count=1)
print("[Keuangan] Menunggu event order...")
channel.basic_consume(queue=queue.method.queue, on_message_callback=callback, auto_ack=False)
channel.start_consuming()
